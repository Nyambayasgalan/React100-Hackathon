import React from 'react';
import { render } from 'react-dom';
import './css/custom.scss';

render(<h1 className='red'>Hello, World</h1>, document.getElementById('root'));